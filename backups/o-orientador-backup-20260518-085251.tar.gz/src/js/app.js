// ═══════════════════════════════════════════════════════════════════════════════
class FinanceApp {
    constructor() {
        this.currentMonth = new Date().toISOString().slice(0, 7)
        this.currentTab = 'resumo'
        this.currentBank = null
        this.showIncForm = false
        this.showExpForm = false
        this.barChart = null
        this.pieChart = null
        this.importer = new ImportService()
        this.importPending = []
        this.currentUser = null
    }

    // ── Inicialização ───────────────────────────────────────────────────────────
    init() {
        document.getElementById('modal-overlay').classList.add('hidden')
        document.getElementById('detail-overlay').classList.add('hidden')
        this._updateCurrentBank()
        this.render()
    }

    // Picks first available bank, or keeps currentBank if still valid
    _updateCurrentBank() {
        const banks = DataStore.getBanksWithData()
        if (!banks.length) { this.currentBank = null; return }
        if (!this.currentBank || !banks.includes(this.currentBank)) {
            this.currentBank = banks[0]
        }
    }

    switchBank(bank) {
        if (bank === 'entre_contas') {
            this.openEntreContasModal()
            return
        }
        this.currentBank = bank
        this.showIncForm = false
        this.showExpForm = false
        this.render()
    }

    // ── Navegação ───────────────────────────────────────────────────────────────
    switchTab(tab) {
        this.currentTab = tab
        this.showIncForm = false
        this.showExpForm = false
        document.querySelectorAll('.tab').forEach((b, i) => {
            b.classList.toggle('active', ['resumo', 'rendas', 'gastos', 'analise'][i] === tab)
        })
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'))
        document.getElementById('sec-' + tab).classList.add('active')
        this.render()
        if (tab === 'analise') setTimeout(() => this._renderCharts(), 50)
    }

    shiftMonth(dir) {
        const [y, mo] = this.currentMonth.split('-').map(Number)
        if (dir < 0) this.currentMonth = mo === 1 ? `${y - 1}-12` : `${y}-${String(mo - 1).padStart(2, '0')}`
        else this.currentMonth = mo === 12 ? `${y + 1}-01` : `${y}-${String(mo + 1).padStart(2, '0')}`
        this.showIncForm = false
        this.showExpForm = false
        this.render()
        if (this.currentTab === 'analise') setTimeout(() => this._renderCharts(), 50)
    }

    // ── Render ──────────────────────────────────────────────────────────────────
    render() {
        document.getElementById('month-label').textContent = Renderer.monthLabel(this.currentMonth)
        const banks = DataStore.getBanksWithData()
        this._updateCurrentBank()
        Renderer.renderBankNav(banks, this.currentBank)
        if (!this.currentBank) {
            document.getElementById('sec-resumo').innerHTML = '<div class="bank-empty"><span class="bank-empty-icon">🏦</span>Importe um extrato para começar.<br><span style="font-size:12px">Arraste um arquivo .CSV, .OFX ou .PDF acima.</span></div>'
            document.getElementById('sec-rendas').innerHTML = ''
            document.getElementById('sec-gastos').innerHTML = ''
            document.getElementById('sec-analise').innerHTML = ''
            return
        }
        Renderer.renderSummary(this.currentMonth, this.currentBank)
        Renderer.renderIncomes(this.currentMonth, this.currentBank, this.showIncForm)
        Renderer.renderExpenses(this.currentMonth, this.currentBank, this.showExpForm)
        Renderer.renderAnalysis(this.currentMonth, this.currentBank)
    }

    _renderCharts() {
        const result = Renderer.renderCharts(this.currentMonth, this.currentBank, this.barChart, this.pieChart)
        this.barChart = result.barChart
        this.pieChart = result.pieChart
    }

    // ── Formulários ─────────────────────────────────────────────────────────────
    toggleIncForm() { this.showIncForm = !this.showIncForm; this.render() }
    toggleExpForm() { this.showExpForm = !this.showExpForm; this.render() }

    addIncome() {
        const name = document.getElementById('inc-name').value.trim()
        const amount = parseFloat(document.getElementById('inc-amount').value)
        if (!name || !amount || amount <= 0) { alert('Preencha nome e valor!'); return }
        const id = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`
        DataStore.addIncome({ id, month: this.currentMonth, name, amount, bank: this.currentBank })
        this.showIncForm = false
        this.render()
    }

    addExpense() {
        const name = document.getElementById('exp-name').value.trim()
        const amount = parseFloat(document.getElementById('exp-amount').value)
        const sector = document.getElementById('exp-sector').value
        const type = document.getElementById('exp-type').value
        const category = document.getElementById('exp-cat').value
        if (!name || !amount || amount <= 0) { alert('Preencha nome e valor!'); return }
        const id = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`
        DataStore.addExpense({ id, month: this.currentMonth, name, amount, type, category, sector, bank: this.currentBank })
        this.showExpForm = false
        this.render()
    }

    removeIncome(id) {
        if (!confirm('Remover esta renda?')) return
        DataStore.removeIncome(id)
        this.render()
    }

    removeExpense(id) {
        if (!confirm('Remover este gasto?')) return
        DataStore.removeExpense(id)
        this.render()
    }

    clearIncomes() {
        const [y, mo] = this.currentMonth.split('-')
        if (!confirm(`Remover todas as rendas de ${MONTH_NAMES[parseInt(mo) - 1]} ${y}?`)) return
        DataStore.clearIncomesByMonth(this.currentMonth, this.currentBank)
        this.render()
    }

    clearExpenses() {
        const [y, mo] = this.currentMonth.split('-')
        if (!confirm(`Remover todas as movimentações de ${MONTH_NAMES[parseInt(mo) - 1]} ${y}?`)) return
        DataStore.clearExpensesByMonth(this.currentMonth, this.currentBank)
        this.render()
    }

    // ── Saldo em conta ──────────────────────────────────────────────────────────
    editBalance(month, bank) {
        const b = bank || this.currentBank
        const current = DataStore.getBalance(month, b)
        const [y, mo] = month.split('-')
        const meta = BANK_META[b] || BANK_META.generico
        const label = `${MONTH_NAMES[parseInt(mo) - 1]} ${y} — ${meta.label}`
        const input = prompt(`Saldo em conta — ${label}\n(valor "Saldo final do período" do extrato)`,
            current !== undefined ? current.toFixed(2).replace('.', ',') : '')
        if (input === null) return
        const val = parseFloat(input.replace(/\./g, '').replace(',', '.'))
        if (isNaN(val)) { alert('Valor inválido.'); return }
        DataStore.setBalance(month, b, val)
        this.render()
    }

    // ── Modal de detalhe do setor ───────────────────────────────────────────────
    showSectorDetail(sector) {
        const items = DataStore.getExpensesByMonth(this.currentMonth, this.currentBank).filter(e => Classifier.sectorOf(e) === sector)
        const [y, mo] = this.currentMonth.split('-')
        const monthName = `${MONTH_NAMES[parseInt(mo) - 1]} ${y}`
        const isInvest = sector === 'investido'
        const aplicacoes = isInvest ? items.filter(e => !e.resgate) : []
        const resgates = isInvest ? items.filter(e => e.resgate) : []
        const totalAplic = aplicacoes.reduce((s, e) => s + e.amount, 0)
        const totalResg = resgates.reduce((s, e) => s + e.amount, 0)
        const total = sector === 'gasto' ? items.reduce((s, e) => s + e.amount, 0) : totalAplic - totalResg
        const icons = { gasto: '💳', investido: '📈' }
        const bankMeta = BANK_META[this.currentBank] || BANK_META.generico
        const fmt = Renderer.fmt.bind(Renderer)
        document.getElementById('detail-title').textContent = `${icons[sector]} ${SECTOR_LABELS[sector]} — ${monthName} · ${bankMeta.icon} ${bankMeta.label}`

        const renderRows = list => {
            if (!list.length) return '<div style="color:var(--text3);font-size:13px;padding:8px 0">Nenhum lançamento</div>'
            return list.map(e => `<div class="row">
        <div>
          <div class="row-name">${Renderer.esc(e.name)}</div>
          ${e.category ? `<div class="row-sub">${Renderer.esc(CAT_LABELS[e.category] || e.category)}</div>` : ''}
        </div>
        <div class="row-right">
          ${e.resgate ? '<span class="badge" style="background:var(--purple-bg);color:var(--purple-text)">↩ Resgate</span>' : ''}
          <span class="amount" style="color:${e.resgate ? 'var(--green)' : 'var(--text)'}">${e.resgate ? '-' : ''}${fmt(e.amount)}</span>
        </div>
      </div>`).join('')
        }

        let html = ''
        if (isInvest) {
            if (aplicacoes.length) html += `<div class="group-label" style="color:var(--purple-text)">Aplicações</div>${renderRows(aplicacoes)}<div class="subtotal"><span>Subtotal aplicado</span><span>${fmt(totalAplic)}</span></div>`
            if (resgates.length) html += `<div class="group-label" style="color:var(--green-text)">Resgates</div>${renderRows(resgates)}<div class="subtotal"><span>Subtotal resgatado</span><span style="color:var(--green)">− ${fmt(totalResg)}</span></div>`
            if (!items.length) html = '<div class="empty"><span class="empty-icon">📈</span>Nenhum lançamento de investimento este mês</div>'
        } else {
            html = renderRows(items)
            if (!items.length) html = '<div class="empty"><span class="empty-icon">💳</span>Nenhum gasto este mês</div>'
        }
        if (items.length) html += `<div class="total-row"><span>Líquido ${SECTOR_LABELS[sector].toLowerCase()}</span><span style="color:${isInvest ? 'var(--purple)' : 'var(--text)'}">${fmt(Math.max(0, total))}</span></div>`

        document.getElementById('detail-body').innerHTML = html
        document.getElementById('detail-overlay').classList.remove('hidden')
    }

    closeDetail() {
        document.getElementById('detail-overlay').classList.add('hidden')
    }

    // ── Importação de extratos ──────────────────────────────────────────────────
    onDragOver(e) { e.preventDefault(); e.stopPropagation(); document.getElementById('dropzone').classList.add('drag-over') }
    onDragLeave(e) { e.preventDefault(); document.getElementById('dropzone').classList.remove('drag-over') }

    onDrop(e) {
        e.preventDefault(); e.stopPropagation()
        document.getElementById('dropzone').classList.remove('drag-over')
        const file = e.dataTransfer.files[0]
        if (!file) return
        const ext = file.name.split('.').pop().toLowerCase()
        if (!['ofx', 'pdf', 'csv'].includes(ext)) { alert('Formato não suportado. Use .CSV, .OFX ou .PDF.'); return }
        this._readFile(file)
    }

    handleFileInput(event) {
        const file = event.target.files[0]
        if (file) this._readFile(file)
        event.target.value = ''
    }

    _readFile(file) {
        // Busca o nome do usuário da fonte mais confiável disponível
        const session = AuthService.getSession()
        const users = JSON.parse(localStorage.getItem(AuthService.USERS_KEY) || '{}')
        const cpf = session?.cpf
        const userName = this.currentUser?.name
            || session?.name
            || (cpf && users[cpf]?.name)
            || null

        const ext = file.name.split('.').pop().toLowerCase()
        if (ext === 'pdf') {
            const dz = document.getElementById('dropzone')
            const origHTML = dz.innerHTML
            const restoreDropzone = () => { dz.innerHTML = origHTML }

            this.importer.setUser(userName) // define ANTES do parsePDF para detecção interna
            this.importer.parsePDF(file, loading => {
                dz.innerHTML = loading
                    ? '<span class="drop-icon" style="opacity:.6">⏳</span><div class="drop-title">Lendo PDF...</div><div class="drop-sub">Aguarde um momento</div>'
                    : origHTML
            }).then(() => {
                if (!this.importer.transactions.length && this.importer.saldoFinal === null) {
                    alert('Nenhuma transação encontrada no PDF.')
                    restoreDropzone()
                    return
                }
                this._openImportModal()
            }).catch(err => {
                restoreDropzone()
                alert('Erro ao ler o PDF: ' + err.message)
            })
        } else {
            const reader = new FileReader()
            reader.onload = e => {
                try {
                    this.importer.reset()
                    this.importer.setUser(userName) // define APÓS reset, não antes
                    if (ext === 'csv') this.importer.parseCSV(e.target.result)
                    else this.importer.parseOFX(e.target.result)
                    if (!this.importer.transactions.length) { alert(`Nenhuma transação encontrada no arquivo ${ext.toUpperCase()}.`); return }
                    this._openImportModal()
                } catch (err) { alert('Erro ao ler o arquivo: ' + err.message) }
            }
            reader.readAsText(file, 'UTF-8')
        }
    }

    _openImportModal() {
        this.importPending = this.importer.transactions.map((t, idx) => ({ ...t, idx }))
        this._renderImportModal()
        document.getElementById('modal-overlay').classList.remove('hidden')
    }

    closeModal() {
        document.getElementById('modal-overlay').classList.add('hidden')
        this.importPending = []
        this.importer.reset()
    }

    _renderImportModal() {
        const fmt = Renderer.fmt.bind(Renderer)
        const pending = this.importPending
        const selected = pending.filter(t => t.selected).length
        document.getElementById('modal-footer-info').textContent = `${selected} de ${pending.length} transações selecionadas`

        const bankLabel = { nubank: 'Nubank', inter: 'Inter', caixa: 'Caixa', generico: 'Banco desconhecido' }
        const bankIcon = { nubank: '🟣', inter: '🟠', caixa: '🔵', generico: '🏦' }
        const bank = this.importer.bank || 'generico'
        const userName = this.importer.userName
        const debugInfo = userName
            ? `🔍 Detectando transferências internas para: <strong>${Renderer.esc(userName)}</strong>`
            : `⚠ Nome do usuário não identificado — transferências internas não serão detectadas. Faça logout e login novamente.`

        let html = `<div class="step-info">
      ${bankIcon[bank]} Banco identificado: <strong>${bankLabel[bank]}</strong> — usando regras específicas para este banco.
      <br>${debugInfo}
      <br>Transações encontradas: <strong>${pending.length}</strong>. <strong>Desmarque</strong> as que não quer importar e ajuste o <strong>setor</strong> se necessário.
    </div>`

        // DEBUG: mostra linhas extraídas do PDF quando banco é Caixa ou não detectado
        if ((bank === 'caixa' || bank === 'generico') && this.importer._debugLines) {
            html += `<div style="background:#fff8e1;border:1px solid #f59e0b;border-radius:var(--rs);padding:10px 12px;margin-bottom:1rem;font-size:11px;font-family:monospace;white-space:pre;overflow:auto;max-height:200px;color:#92400e">📋 Banco: ${bank} | Linhas extraídas (debug):\n${Renderer.esc(this.importer._debugLines)}</div>`
        }

        if (this.importer.saldoFinal !== null) {
            const [y, mo] = (this.importer.saldoMonth || '').split('-')
            const mLabel = mo ? `${MONTH_NAMES[parseInt(mo) - 1]} ${y}` : ''
            html += `<div style="background:var(--green-bg);color:var(--green-text);border-radius:var(--rs);padding:10px 14px;font-size:13px;margin-bottom:1rem;display:flex;align-items:center;justify-content:space-between;gap:12px">
        <span>🏦 <strong>Saldo final detectado:</strong> ${fmt(this.importer.saldoFinal)} ${mLabel ? `<span style="opacity:.7">· ${mLabel}</span>` : ''}</span>
        <span style="opacity:.7;font-size:12px">Será salvo como "Em conta"</span>
      </div>`
        }

        html += `<div class="sel-all-row"><input type="checkbox" id="chk-all" checked onchange="app.toggleAllImport(this.checked)"><label for="chk-all">Selecionar / desmarcar tudo</label></div>`

        const byMonth = {}
        pending.forEach(t => { if (!byMonth[t.month]) byMonth[t.month] = []; byMonth[t.month].push(t) })

        for (const [month, txs] of Object.entries(byMonth).sort((a, b) => b[0].localeCompare(a[0]))) {
            const [y, mo] = month.split('-')
            html += `<div style="font-size:12px;font-weight:600;color:var(--text3);text-transform:uppercase;letter-spacing:.05em;padding:10px 0 6px;border-top:1px solid var(--border)">${MONTH_NAMES[parseInt(mo) - 1]} ${y}</div>`
            html += `<table class="import-table"><thead><tr><th style="width:32px"></th><th>Descrição</th><th>Data</th><th>Valor</th><th>Setor</th><th>Tipo</th></tr></thead><tbody>`
            txs.forEach(t => {
                const sectorOpts = ['gasto', 'investido', 'em_conta'].map(s => `<option value="${s}" ${(t.sector || 'gasto') === s ? 'selected' : ''}>${SECTOR_LABELS[s]}</option>`).join('')
                html += `<tr id="row-${t.idx}" class="${t.selected ? '' : 'skip'}">
          <td><input type="checkbox" ${t.selected ? 'checked' : ''} onchange="app.toggleImportRow(${t.idx},this.checked)"></td>
          <td><div class="imp-desc">${Renderer.esc(t.memo)}</div></td>
          <td class="imp-date">${t.dateStr}</td>
          <td class="imp-amount ${t.isIncome ? 'imp-income' : 'imp-expense'}">${t.isIncome ? '+' : '-'} ${fmt(t.amount)}</td>
          <td>${t.isIncome ? '<span style="color:var(--text3);font-size:12px">Renda</span>' :
                        t.resgate ? '<span style="background:var(--purple-bg);color:var(--purple-text);font-size:11px;padding:2px 8px;border-radius:20px;font-weight:500">↩ Resgate investido</span>' :
                            t.internal ? '<span style="background:var(--green-bg);color:var(--green-text);font-size:11px;padding:2px 8px;border-radius:20px;font-weight:500">🔁 Entre contas</span>' :
                                `<select onchange="app.setImportSector(${t.idx},this.value)">${sectorOpts}</select>`}</td>
          <td>${t.isIncome || t.sector === 'investido' || t.sector === 'em_conta' ? '' :
                        `<select onchange="app.setImportType(${t.idx},this.value)">
  <option value="variavel" ${t.expType === 'variavel' ? 'selected' : ''}>Variável</option>
  <option value="fixo" ${t.expType === 'fixo' ? 'selected' : ''}>Fixo</option>
</select>`}</td>
        </tr>`
            })
            html += `</tbody></table>`
        }

        document.getElementById('modal-body').innerHTML = html
    }

    toggleImportRow(idx, checked) {
        this.importPending[idx].selected = checked
        document.getElementById('row-' + idx).className = checked ? '' : 'skip'
        const sel = this.importPending.filter(t => t.selected).length
        document.getElementById('modal-footer-info').textContent = `${sel} de ${this.importPending.length} transações selecionadas`
    }

    toggleAllImport(checked) {
        this.importPending.forEach((_, i) => {
            this.importPending[i].selected = checked
            const row = document.getElementById('row-' + i)
            if (row) row.className = checked ? '' : 'skip'
        })
        const sel = this.importPending.filter(t => t.selected).length
        document.getElementById('modal-footer-info').textContent = `${sel} de ${this.importPending.length} transações selecionadas`
    }

    setImportSector(idx, val) { this.importPending[idx].sector = val; this._renderImportModal() }
    setImportType(idx, val) { this.importPending[idx].expType = val }


    openEntreContasModal() {
        const fmt = Renderer.fmt.bind(Renderer)
        const esc = Renderer.esc.bind(Renderer)
        const data = DataStore.load()
        const month = this.currentMonth
        // Pega todas as saídas 'entre_contas' do mês em todos os bancos
        const items = data.expenses.filter(e => e.month === month && e.sector === 'entre_contas')
        const total = items.reduce((s, e) => s + e.amount, 0)
        const [y, mo] = month.split('-')
        const monthName = `${MONTH_NAMES[parseInt(mo) - 1]} ${y}`

        // Render into the existing detail modal
        document.getElementById('detail-title').textContent = `🔁 Entre contas — ${monthName}`
        let html = ``

        if (!items.length) {
            html += `<div class="empty"><span class="empty-icon">🔁</span>
        Nenhuma movimentação interna encontrada este mês.<br>
        <span style="font-size:12px">Transferências enviadas para você mesmo aparecerão aqui.</span>
      </div>`
        } else {
            html += `<div class="card">`
            // Agrupa por banco de origem
            const byBank = {}
            items.forEach(e => {
                const b = e.bank || 'generico'
                if (!byBank[b]) byBank[b] = []
                byBank[b].push(e)
            })

            for (const [bank, list] of Object.entries(byBank)) {
                const meta = BANK_META[bank] || BANK_META.generico
                const subtotal = list.reduce((s, e) => s + e.amount, 0)
                html += `<div class="group-label" style="color:${meta.color}">${meta.icon} Saiu do ${meta.label}</div>`
                list.forEach(e => {
                    html += `<div class="row">
<div>
  <div class="row-name">${esc(e.name)}</div>
</div>
<div class="row-right">
  <span class="badge" style="background:var(--green-bg);color:var(--green-text)">🔁 Interno</span>
  <span class="amount">${fmt(e.amount)}</span>
</div>
          </div>`
                })
                html += `<div class="subtotal"><span>Subtotal ${meta.label}</span><span>${fmt(subtotal)}</span></div>`
            }

            html += `<div class="total-row"><span>Total movimentado entre contas</span><span>${fmt(total)}</span></div>`

            html += `<div class="alert" style="background:var(--green-bg);color:var(--green-text);margin-top:1rem">
        ✓ Estes valores <strong>não contam como gasto</strong> em nenhum banco — são apenas transferências entre suas próprias contas.
      </div>`
            html += `</div>`
        }

        document.getElementById('detail-body').innerHTML = html
        document.getElementById('detail-overlay').classList.remove('hidden')
    }

    confirmImport() {
        const toImport = this.importPending.filter(t => t.selected)
        if (!toImport.length) { alert('Nenhuma transação selecionada.'); return }

        const data = DataStore.load()
        toImport.forEach(t => {
            const id = Date.now() + Math.random()
            if (t.isIncome && !t.resgate) {
                data.incomes.push({ id, month: t.month, name: t.memo, amount: t.amount, bank: this.importer.bank })
            } else {
                data.expenses.push({
                    id, month: t.month, name: t.memo, amount: t.amount,
                    type: t.expType, category: t.category || 'outros',
                    sector: t.internal ? 'entre_contas' : (t.sector || 'gasto'),
                    resgate: t.resgate || false,
                    internal: t.internal || false,
                    bank: this.importer.bank
                })
            }
        })

        if (this.importer.saldoFinal !== null && this.importer.saldoMonth) {
            if (!data.balances) data.balances = {}
            data.balances[`${this.importer.saldoMonth}::${this.importer.bank}`] = this.importer.saldoFinal
        }

        DataStore.save(data)
        this.closeModal()

        const months = toImport.map(t => t.month).sort().reverse()
        if (months.length) this.currentMonth = months[0]
        this.currentBank = 'geral'

        this.render()
        alert(`✓ ${toImport.length} transações importadas com sucesso!`)
    }
}

window.FinanceApp = FinanceApp
