// ═══════════════════════════════════════════════════════════════════════════════
class BankDetector {

    // Detecta banco a partir de texto (CSV ou OFX)
    static fromText(text, ext) {
        const sample = text.slice(0, 1500).toLowerCase()

        if (ext === 'ofx') return this._detectOFX(sample)
        if (ext === 'csv') return this._detectCSV(sample)
        return 'generico'
    }

    // Detecta banco a partir de linhas extraídas de PDF
    static fromPDFLines(lines) {
        const sample = lines.join(' ').toLowerCase()
        if (sample.includes('nu pagamentos') || sample.includes('nu financeira') || sample.includes('nubank')) return 'nubank'
        if (sample.includes('banco inter') || sample.includes('inter s.a')) return 'inter'
        if (sample.includes('deposito dinh') || sample.includes('saldo anterior') && sample.includes('saldo do dia') || sample.includes('caixa economica')) return 'caixa'
        return 'generico'
    }

    static _detectOFX(sample) {
        if (sample.includes('nubank') || sample.includes('nu pagamentos')) return 'nubank'
        if (sample.includes('banco inter') || sample.includes('inter s.a')) return 'inter'
        return 'generico'
    }

    static _detectCSV(sample) {
        // Nubank: tem coluna "identificador" no cabeçalho
        if (sample.includes('identificador')) return 'nubank'
        // Inter: primeira linha contém "extrato conta corrente"
        if (sample.includes('extrato conta corrente')) return 'inter'
        return 'generico'
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CLASS: BankProfile — palavras-chave específicas por banco

window.BankDetector = BankDetector
