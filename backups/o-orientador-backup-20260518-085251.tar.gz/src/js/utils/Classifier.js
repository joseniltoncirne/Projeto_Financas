// ═══════════════════════════════════════════════════════════════════════════════
class Classifier {
    static AUTO_CATS = {
        moradia: ['aluguel', 'condomin', 'luz', 'energia', 'agua', 'gás', 'gas', 'internet', 'telefone', 'claro', 'vivo', 'tim', 'oi', 'net ', 'sky '],
        alimentacao: ['mercado', 'supermercado', 'ifood', 'rappi', 'ubereats', 'restaurante', 'lanchonete', 'padaria', 'açougue', 'acougue', 'hortifruti', 'delivery', 'burger', 'pizza', 'sushi', 'mcdonalds', 'subway'],
        transporte: ['uber', '99pop', 'cabify', 'posto ', 'combustivel', 'gasolina', 'etanol', 'estacionamento', 'metrô', 'metro', 'onibus', 'ônibus', 'bilhete', 'shell', 'ipiranga', 'br dis'],
        saude: ['farmacia', 'drogaria', 'drogas', 'ultrafarma', 'pague menos', 'hospital', 'clinica', 'clínica', 'medico', 'médico', 'laboratorio', 'laboratório', 'exame', 'unimed', 'amil', 'hapvida', 'prevent'],
        educacao: ['escola', 'faculdade', 'universidade', 'curso', 'udemy', 'alura', 'coursera', 'livraria', 'saraiva', 'cultura'],
        lazer: ['netflix', 'spotify', 'amazon', 'disney', 'hbo', 'apple', 'steam', 'playstation', 'xbox', 'cinema', 'teatro', 'parque', 'viagem', 'hotel', 'airbnb'],
        cartao: ['pagamento de fatura', 'pagamento fatura', 'fatura cartão', 'fatura cartao', 'fatura nubank', 'fatura inter', 'fatura bradesco', 'fatura itau', 'fatura santander'],
    }

    static category(memo) {
        const m = memo.toLowerCase()
        for (const [cat, keywords] of Object.entries(this.AUTO_CATS)) {
            if (keywords.some(k => m.includes(k))) return cat
        }
        return 'outros'
    }

    static sector(memo, bank = 'generico') {
        return BankProfile.sector(memo, bank)
    }

    static isResgate(memo, isIncome, bank = 'generico') {
        return BankProfile.isResgate(memo, isIncome, bank)
    }

    static sectorOf(expense) {
        return expense.sector || 'gasto'
    }

    // Verifica se uma transação é entre contas do mesmo titular
    // Suporta nome completo e abreviações (ex: "Josenilton C R Neto")
    static isInternalTransfer(memo, isOutgoing, userName) {
        if (!userName || !isOutgoing) return false

        const m = memo.toUpperCase().trim()
        const u = userName.toUpperCase().trim()
        const parts = u.split(/\s+/).filter(p => p.length > 1)

        if (!parts.length) return false

        // ── Nível 1: match exato (nome completo presente) ───────────────────────
        if (m.includes(u)) return true

        // ── Nível 2: primeiro nome + último sobrenome ambos presentes ────────────
        const first = parts[0]
        const last = parts[parts.length - 1]
        if (first !== last && m.includes(first) && m.includes(last)) return true

        // ── Nível 3: pelo menos 3 partes do nome completo presentes ──────────────
        // Ignora partículas curtas (de, da, do, dos, das)
        const significant = parts.filter(p => p.length >= 3)
        if (significant.length >= 3) {
            const matches = significant.filter(p => m.includes(p))
            if (matches.length >= 3) return true
        }

        return false
    }

    static buildTransaction(memo, amount, dateStr, month, bank = 'generico', userName = null) {
        const isIncome = amount > 0
        const absAmount = Math.abs(amount)
        const resgate = this.isResgate(memo, isIncome, bank)
        const internal = !isIncome && !resgate && this.isInternalTransfer(memo, !isIncome, userName)
        const sector = resgate ? 'investido' :
            internal ? 'entre_contas' :
                !isIncome ? this.sector(memo, bank) : null
        const id = typeof crypto !== 'undefined' && crypto.randomUUID
            ? crypto.randomUUID()
            : `${Date.now()}-${Math.random().toString(36).slice(2)}`
        return {
            id,
            month, dateStr, memo, amount: absAmount,
            isIncome: isIncome && !resgate,
            resgate, sector, internal,
            category: (!isIncome && !resgate && !internal) ? this.category(memo) : null,
            expType: 'variavel',
            selected: true,
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CLASS: ImportService — responsável por parsear CSV, OFX e PDF

window.Classifier = Classifier
