'use strict'

// ═══════════════════════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════════
var MONTH_NAMES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']
var MONTH_SHORT = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
var CAT_LABELS = { moradia: 'Moradia', alimentacao: 'Alimentação', transporte: 'Transporte', saude: 'Saúde', educacao: 'Educação', lazer: 'Lazer', cartao: 'Cartão', outros: 'Outros' }
var CAT_COLORS = { moradia: '#2e7fd8', alimentacao: '#1a9e74', transporte: '#b87316', saude: '#d45828', educacao: '#6040c8', lazer: '#c83f7a', cartao: '#0891b2', outros: '#888880' }
var PIE_COLORS = ['#2e7fd8', '#1a9e74', '#b87316', '#d45828', '#6040c8', '#c83f7a', '#888880']
var SECTOR_LABELS = { gasto: 'Gasto', investido: 'Investido', em_conta: 'Em conta', entre_contas: 'Entre contas' }
var SECTOR_COLORS = {
    gasto: { bg: 'var(--red-bg)', text: 'var(--red-text)', accent: 'var(--red)' },
    investido: { bg: 'var(--purple-bg)', text: 'var(--purple-text)', accent: 'var(--purple)' },
    em_conta: { bg: 'var(--surface2)', text: 'var(--text2)', accent: 'var(--text3)' },
    entre_contas: { bg: 'var(--green-bg)', text: 'var(--green-text)', accent: 'var(--green)' },
}
var BANK_META = {
    nubank: { label: 'Nubank', icon: '🟣', color: '#8A05BE', bg: '#F3E8FF', textColor: '#5C0A7E' },
    inter: { label: 'Inter', icon: '🟠', color: '#FF6200', bg: '#FFF0E6', textColor: '#9A3A00' },
    generico: { label: 'Outros', icon: '🏦', color: '#5a5a55', bg: '#f0efe9', textColor: '#2a2a28' },
    caixa: { label: 'Caixa', icon: '🔵', color: '#005CA9', bg: '#E6F0FA', textColor: '#003870' },
}

// ═══════════════════════════════════════════════════════════════════════════════
// CLASS: AuthService — autenticação local (preparado para migração a API REST)
// Futuramente: trocar localStorage por chamadas POST /auth/login e /auth/register
