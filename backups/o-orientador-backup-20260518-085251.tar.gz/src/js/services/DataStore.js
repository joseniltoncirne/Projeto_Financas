// ═══════════════════════════════════════════════════════════════════════════════
class DataStore {
    static KEY = 'mf_data' // Overridden per session via setUser()

    static setUser(cpf) {
        this.KEY = AuthService.dataKey(cpf)
    }

    static load() {
        try {
            return this._normalize(JSON.parse(localStorage.getItem(this.KEY)) || this._empty())
        } catch {
            return this._empty()
        }
    }

    static save(data) {
        if (!data.balances) data.balances = {}
        try {
            localStorage.setItem(this.KEY, JSON.stringify(data))
        } catch (e) {
            if (e.name === 'QuotaExceededError' || e.code === 22) {
                alert('⚠ Armazenamento cheio! Não foi possível salvar os dados. Considere limpar meses antigos para liberar espaço.')
            } else {
                console.error('Erro ao salvar dados:', e)
            }
        }
    }

    static _empty() {
        return { incomes: [], expenses: [], balances: {} }
    }

    static _normalize(data) {
        const normalized = data && typeof data === 'object' ? data : this._empty()
        return {
            incomes: Array.isArray(normalized.incomes) ? normalized.incomes : [],
            expenses: Array.isArray(normalized.expenses) ? normalized.expenses : [],
            balances: normalized.balances && typeof normalized.balances === 'object' && !Array.isArray(normalized.balances)
                ? normalized.balances
                : {},
        }
    }

    static addIncome(income) {
        const data = this.load()
        data.incomes.push(income)
        this.save(data)
    }

    static addExpense(expense) {
        const data = this.load()
        data.expenses.push(expense)
        this.save(data)
    }

    static removeIncome(id) {
        const data = this.load()
        data.incomes = data.incomes.filter(i => String(i.id) !== String(id))
        this.save(data)
    }

    static removeExpense(id) {
        const data = this.load()
        data.expenses = data.expenses.filter(e => String(e.id) !== String(id))
        this.save(data)
    }

    static clearIncomesByMonth(month, bank) {
        const data = this.load()
        data.incomes = data.incomes.filter(i => !(i.month === month && i.bank === bank))
        this.save(data)
    }

    static clearExpensesByMonth(month, bank) {
        const data = this.load()
        data.expenses = data.expenses.filter(e => !(e.month === month && e.bank === bank))
        this.save(data)
    }

    // Remove todos os dados de um banco em todos os meses
    static clearAllByBank(bank) {
        const data = this.load()
        data.incomes = data.incomes.filter(i => i.bank !== bank)
        data.expenses = data.expenses.filter(e => e.bank !== bank)
        // Remove saldos do banco
        Object.keys(data.balances).forEach(k => {
            if (k.endsWith(`::${bank}`)) delete data.balances[k]
        })
        this.save(data)
    }

    static setBalance(month, bank, value) {
        const data = this.load()
        if (!data.balances) data.balances = {}
        data.balances[`${month}::${bank}`] = value
        this.save(data)
    }

    static getBalance(month, bank) {
        return (this.load().balances || {})[`${month}::${bank}`]
    }

    static getIncomesByMonth(month, bank) {
        return this.load().incomes.filter(i => i.month === month && i.bank === bank)
    }

    static getExpensesByMonth(month, bank) {
        return this.load().expenses.filter(e => e.month === month && e.bank === bank)
    }

    // Retorna todas as saídas classificadas como entre_contas de um mês
    static getEntreContasByMonth(month) {
        return this.load().expenses.filter(e => e.month === month && e.sector === 'entre_contas')
    }

    // Returns sorted list of unique banks that have any data
    static getBanksWithData() {
        const data = this.load()
        const banks = new Set()
        data.incomes.forEach(i => { if (i.bank) banks.add(i.bank) })
        data.expenses.forEach(e => { if (e.bank) banks.add(e.bank) })
        const order = ['nubank', 'inter', 'generico']
        return [...banks].sort((a, b) => {
            const ia = order.indexOf(a), ib = order.indexOf(b)
            return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib)
        })
    }

    static getAllMonthsWithData() {
        const months = []
        const now = new Date()
        const baseYear = now.getFullYear()
        const baseMonth = now.getMonth() // 0-indexed
        for (let i = 5; i >= 0; i--) {
            let mo = baseMonth - i
            let y = baseYear
            if (mo < 0) { mo += 12; y -= 1 }
            months.push(`${y}-${String(mo + 1).padStart(2, '0')}`)
        }
        return months
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CLASS: BankDetector — identifica o banco pelo conteúdo do arquivo

window.DataStore = DataStore
