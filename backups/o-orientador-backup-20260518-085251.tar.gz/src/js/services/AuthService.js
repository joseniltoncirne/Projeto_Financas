// ═══════════════════════════════════════════════════════════════════════════════
class AuthService {
    static USERS_KEY = 'mf_users'
    static SESSION_KEY = 'mf_session'

    // Hash simples do CPF (futuramente: bcrypt no backend)
    static _hash(cpf) {
        const clean = cpf.replace(/\D/g, '')
        let h = 0
        for (const c of clean) h = (Math.imul(31, h) + c.charCodeAt(0)) | 0
        return h.toString(36)
    }

    // Formata CPF: 12345678900 → 123.456.789-00
    static formatCPF(value) {
        const d = value.replace(/\D/g, '').slice(0, 11)
        if (d.length <= 3) return d
        if (d.length <= 6) return `${d.slice(0, 3)}.${d.slice(3)}`
        if (d.length <= 9) return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6)}`
        return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9)}`
    }

    static validateCPF(cpf) {
        const d = cpf.replace(/\D/g, '')
        return d.length === 11
    }

    static validateName(name) {
        const parts = name.trim().split(/\s+/)
        return parts.length >= 2 && parts.every(p => p.length >= 2)
    }

    static _loadUsers() {
        try { return JSON.parse(localStorage.getItem(this.USERS_KEY)) || {} } catch { return {} }
    }

    static _saveUsers(users) {
        localStorage.setItem(this.USERS_KEY, JSON.stringify(users))
    }

    // Futuramente → POST /auth/register
    static register(fullName, cpf) {
        const name = fullName.trim().toUpperCase()
        const clean = cpf.replace(/\D/g, '')
        if (!this.validateName(name)) return { ok: false, error: 'Informe nome e sobrenome completos (sem abreviações)' }
        if (!this.validateCPF(cpf)) return { ok: false, error: 'CPF inválido' }
        const users = this._loadUsers()
        if (users[clean]) return { ok: false, error: 'CPF já cadastrado. Faça login.' }
        users[clean] = { name, hash: this._hash(clean), createdAt: new Date().toISOString() }
        this._saveUsers(users)
        return this._createSession(clean, users[clean])
    }

    // Futuramente → POST /auth/login
    static login(cpf) {
        const clean = cpf.replace(/\D/g, '')
        if (!this.validateCPF(cpf)) return { ok: false, error: 'CPF inválido' }
        const users = this._loadUsers()
        const user = users[clean]
        if (!user) return { ok: false, error: 'CPF não encontrado. Crie uma conta primeiro.' }
        if (!user.name) return { ok: false, error: 'Cadastro antigo ou incompleto. Crie a conta novamente.' }
        return this._createSession(clean, user)
    }

    static _createSession(cpfClean, user) {
        const session = { cpf: cpfClean, name: user.name, loginAt: new Date().toISOString() }
        localStorage.setItem(this.SESSION_KEY, JSON.stringify(session))
        return { ok: true, session }
    }

    // Futuramente → verificar token JWT expirado
    static getSession() {
        try { return JSON.parse(localStorage.getItem(this.SESSION_KEY)) } catch { return null }
    }

    static logout() {
        localStorage.removeItem(this.SESSION_KEY)
    }

    // Chave de dados isolada por usuário (CPF) — futuramente será user_id no banco
    static dataKey(cpf) {
        return `mf_data_${cpf}`
    }

    // Primeiro nome para exibição no header
    static displayName(fullName) {
        const parts = String(fullName || '').trim().split(/\s+/).filter(Boolean)
        return parts.length >= 2 ? `${parts[0]} ${parts[parts.length - 1]}` : parts[0]
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CLASS: AuthUI — interface da tela de login/cadastro

window.AuthService = AuthService
