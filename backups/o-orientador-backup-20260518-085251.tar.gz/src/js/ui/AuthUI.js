// ═══════════════════════════════════════════════════════════════════════════════
class AuthUI {
    constructor(onSuccess) {
        this.mode = 'login'
        this.onSuccess = onSuccess
    }

    showLogin() {
        this.mode = 'login'
        document.getElementById('tab-login').classList.add('active')
        document.getElementById('tab-register').classList.remove('active')
        this._render()
    }

    showRegister() {
        this.mode = 'register'
        document.getElementById('tab-register').classList.add('active')
        document.getElementById('tab-login').classList.remove('active')
        this._render()
    }

    _render() {
        const form = document.getElementById('auth-form')
        if (this.mode === 'register') {
            form.innerHTML = `
        <div class="auth-field">
          <label class="auth-label">Nome completo</label>
          <input class="auth-input" id="auth-name" type="text" placeholder="Ex: João Silva Souza" autocomplete="name">
          <span class="auth-hint">Sem abreviações — será usado para identificar suas transferências</span>
        </div>
        <div class="auth-field">
          <label class="auth-label">CPF (sua senha de acesso)</label>
          <input class="auth-input" id="auth-cpf" type="text" placeholder="000.000.000-00" maxlength="14" oninput="auth.maskCPF(this)" autocomplete="off">
        </div>
        <div id="auth-error"></div>
        <button class="auth-btn" onclick="auth.submit()">Criar conta</button>`
        } else {
            form.innerHTML = `
        <div class="auth-field">
          <label class="auth-label">CPF</label>
          <input class="auth-input" id="auth-cpf" type="text" placeholder="000.000.000-00" maxlength="14" oninput="auth.maskCPF(this)" autocomplete="off">
        </div>
        <div id="auth-error"></div>
        <button class="auth-btn" onclick="auth.submit()">Entrar</button>`
        }
        // Focus first input
        setTimeout(() => document.getElementById(this.mode === 'register' ? 'auth-name' : 'auth-cpf')?.focus?.(), 50)
    }

    maskCPF(input) {
        input.value = AuthService.formatCPF(input.value)
    }

    submit() {
        const cpfInput = document.getElementById('auth-cpf')
        const cpf = cpfInput?.value || ''
        const errorEl = document.getElementById('auth-error')
        errorEl.innerHTML = ''

        let result
        if (this.mode === 'register') {
            const name = document.getElementById('auth-name')?.value || ''
            result = AuthService.register(name, cpf)
        } else {
            result = AuthService.login(cpf)
        }

        if (!result.ok) {
            errorEl.innerHTML = `<div class="auth-error">${Renderer.esc(result.error)}</div>`
            cpfInput?.classList.add('error')
            return
        }

        this.onSuccess(result.session)
    }

    toggleDropdown() {
        document.getElementById('user-dropdown').classList.toggle('open')
    }

    logout() {
        AuthService.logout()
        document.getElementById('user-dropdown').classList.remove('open')
        document.getElementById('app-header').style.display = 'none'
        document.getElementById('app-main').style.display = 'none'
        document.getElementById('auth-screen').style.display = 'flex'
        this.showLogin()
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CLASS: DataStore — responsável por persistência no localStorage

window.AuthUI = AuthUI
