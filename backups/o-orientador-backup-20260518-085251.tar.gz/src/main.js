// ═══════════════════════════════════════════════════════════════════════════════
// INIT — autenticação e inicialização
// Futuramente: trocar AuthService por chamadas à API REST
// ═══════════════════════════════════════════════════════════════════════════════

const app = new FinanceApp()
window.app = app

function onLoginSuccess(session) {
    try {
        if (!session?.cpf || !session?.name) {
            throw new Error('Sessão inválida ou incompleta')
        }

        // Isola dados por usuário (CPF) — futuramente será user_id no servidor
        DataStore.setUser(session.cpf)

        // Atualiza header
        document.getElementById('user-name-display').textContent = AuthService.displayName(session.name)
        document.getElementById('user-dropdown-info').textContent = session.name

        // Mostra app, esconde tela de auth
        document.getElementById('auth-screen').style.display = 'none'
        document.getElementById('app-header').style.display = 'block'
        document.getElementById('app-main').style.display = 'block'

        app.currentUser = session
        app.init()
    } catch (error) {
        console.error('Erro ao iniciar o aplicativo:', error)
        AuthService.logout()
        document.getElementById('app-header').style.display = 'none'
        document.getElementById('app-main').style.display = 'none'
        document.getElementById('auth-screen').style.display = 'flex'
        auth.showLogin()
    }
}

// Fecha dropdown ao clicar fora
document.addEventListener('click', e => {
    const btn = document.getElementById('user-btn')
    if (btn && !btn.contains(e.target)) {
        document.getElementById('user-dropdown')?.classList.remove('open')
    }
})

const auth = new AuthUI(onLoginSuccess)
window.auth = auth
auth.showLogin()

// Retoma sessão existente automaticamente
const existingSession = AuthService.getSession()
if (existingSession?.cpf && existingSession?.name) {
    onLoginSuccess(existingSession)
} else if (existingSession) {
    AuthService.logout()
}
