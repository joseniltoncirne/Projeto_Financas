# Relatório de QA - O Orientador

Data: 2026-05-18T11:36:52.162Z
URL testada: http://localhost:5174/
Navegador: Google Chrome via playwright-core
Status geral: APROVADO

## Resultado dos Testes
- PASS: Tela de login visível
- PASS: Formulário de login renderizado
- PASS: Ação Entrar disponível
- PASS: Tela de cadastro exibe nome completo
- PASS: Tela de cadastro exibe CPF
- PASS: App principal visível após cadastro/login
- PASS: Header visível após login
- PASS: Resumo vazio orienta importação
- PASS: App principal visível com sessão retomada
- PASS: Tela Resumo renderiza uso da renda
- PASS: Tela Resumo renderiza categorias
- PASS: Clique na aba Rendas
- PASS: Tela Rendas renderiza card
- PASS: Tela Rendas mostra total
- PASS: Clique na aba Gastos
- PASS: Tela Gastos renderiza card
- PASS: Tela Gastos mostra subtotal
- PASS: Tela Gastos mostra total
- PASS: Clique na aba Análise
- PASS: Tela Análise renderiza histórico
- PASS: Tela Análise renderiza regra 50/30/20
- PASS: Charts presentes na tela de análise ({"bar":true,"pie":true,"chartLib":true,"barWidth":770,"pieWidth":180})
- PASS: Menu do usuário abre com ação de sair
- PASS: Logout retorna para tela de login

## Erros de Console / Runtime
- Nenhum erro de runtime capturado pelo Playwright após correção do favicon.

## Evidências
- qa-screenshots/01-login.png
- qa-screenshots/02-cadastro.png
- qa-screenshots/03-dashboard-vazio.png
- qa-screenshots/04-resumo-com-dados.png
- qa-screenshots/05-rendas.png
- qa-screenshots/06-gastos.png
- qa-screenshots/07-analise.png
- qa-screenshots/08-menu-usuario.png
- qa-screenshots/09-logout.png
